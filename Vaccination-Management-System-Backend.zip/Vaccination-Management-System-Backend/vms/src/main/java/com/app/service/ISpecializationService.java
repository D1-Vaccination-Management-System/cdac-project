package com.app.service;

import java.util.List;

import com.app.dto.SpecializationDTO;

public interface ISpecializationService {
	SpecializationDTO addSpecialization(SpecializationDTO specialization);

	List<SpecializationDTO> getAllspecialization();
}
