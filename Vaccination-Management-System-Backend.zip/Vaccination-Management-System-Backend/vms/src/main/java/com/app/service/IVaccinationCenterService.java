package com.app.service;

import com.app.dto.ApiResponse;
import com.app.dto.GetVaccinationCenterDetailsDTO;
import com.app.dto.VaccinationCenterDTO;

public interface IVaccinationCenterService {

	ApiResponse addVaccinationCenter(VaccinationCenterDTO dto);

	ApiResponse updateVaccinationCenter(Long id, VaccinationCenterDTO dto);

	GetVaccinationCenterDetailsDTO getAllDetails(Long id);
	
	ApiResponse deleteVaccinationCenter(Long id);

}