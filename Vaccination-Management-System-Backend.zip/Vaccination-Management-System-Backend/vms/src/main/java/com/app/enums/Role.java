package com.app.enums;

public enum Role {
	ROLE_PATIENT,
    ROLE_ADMIN,
    ROLE_DOCTOR,
    ROLE_HEALTH_STAFF
}
