package com.app.entities;

public enum Appointment_Status {
	SCHEDULED,
    COMPLETED,
    CANCELED,
    PENDING,
    RESCHEDULED,
}
